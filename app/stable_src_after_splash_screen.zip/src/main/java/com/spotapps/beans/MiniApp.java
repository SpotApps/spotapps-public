package com.spotapps.beans;

/**
 * Created by tty on 4/5/2015.
 */
public interface MiniApp {

    String getIcon();

    String getDescription();

    String getOperation();

    String getParams();

    Spot getSpot();


}
