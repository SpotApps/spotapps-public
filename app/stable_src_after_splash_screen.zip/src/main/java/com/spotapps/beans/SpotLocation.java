package com.spotapps.beans;

import android.location.Location;

/**
 * Created by tty on 4/5/2015.
 */
public class SpotLocation {

    private Location locationA;
    private Location locationB;

    public SpotLocation(Location locationA, Location locationB){
        this.locationA = locationA;
        this.locationB = locationB;
    }
}
