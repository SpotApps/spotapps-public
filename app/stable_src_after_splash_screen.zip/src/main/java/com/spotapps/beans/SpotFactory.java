package com.spotapps.beans;

/**
 * Created by tty on 4/6/2015.
 */
public abstract class SpotFactory {



    public static Spot createSpot(String name, SpotLocation location) {
        return new DefaultSpot(name, location);
    }
}
