package com.spotapps.beans;

/**
 * Created by tty on 4/5/2015.
 */
public interface Spot {

    String getName();

    SpotLocation getLocation();
}
