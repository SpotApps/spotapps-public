package com.spotapps.beans;

/**
 * Created by tty on 9/9/2015.
 */
public interface SpotKey {
    SpotLocation getCurrentLocation();
}
