package com.spotapps.beans;

import android.os.Bundle;

/**
 * Created by tty on 9/9/2015.
 */
public class SpotBundleUtils {
    private static final String SPOT = "SPOT";
    public static Spot loadSpotFromBundle(Bundle bundle){
        return (Spot)bundle.getSerializable(SPOT);
    }

    public static void storeSpotInBundle(Bundle bundle, Spot spot){
        bundle.putSerializable(SPOT, spot);
    }

}
