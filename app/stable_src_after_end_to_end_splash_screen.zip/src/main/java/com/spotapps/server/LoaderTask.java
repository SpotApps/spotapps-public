package com.spotapps.server;

/**
 * Created by tty on 4/20/2015.
 */
public class LoaderTask {
}
